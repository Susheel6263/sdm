import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;
//import jdk.internal.org.jline.terminal.TerminalBuilder.SystemOutput;

public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		driver.get("http://demo.guru99.com/test/radio.html");
		WebElement radio1=driver.findElement(By.id("vfb-7-1"));
		WebElement radio2=driver.findElement(By.id("vfb-7-2"));
		
		WebElement check1=driver.findElement(By.id("vfb-6-0"));
		WebElement check2=driver.findElement(By.id("vfb-6-1"));
		WebElement check3=driver.findElement(By.id("vfb-6-2"));
//		WebElement radio2=driver.findElement(By.id("vfb-7-2"));
		
		
		
//		radio1.click();
//		System.out.println("Radio1 is Selected");
		
		radio2.click();
		System.out.println("Radio2 is Selected");
		
		check2.click();
		System.out.println("Check2 is Selected");
	}

}
