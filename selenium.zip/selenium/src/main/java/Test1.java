//...This for edge setup...
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-geerated method stub
		WebDriverManager.edgedriver().setup(); //used to setup the edgedriver from the Webdriver Class 
		WebDriver driver = new EdgeDriver(); //Creating the obj for Webdriver
		driver.get("https://www.instagram.com/"); // using obj and get() method we are accessing the URL
	
	}

}


//..This is for google setup..

//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
////import org.openqa.selenium.edge.EdgeDriver;
//
//import io.github.bonigarcia.wdm.WebDriverManager;
//
//public class Test1 {
//	
//	public static void main(String[] args) {
//		// TODO Auto-geerated method stub
//		WebDriverManager.chromedriver().setup();
//		WebDriver driver = new ChromeDriver();
//		driver.get("https://www.google.com");
//	
//	}
//
//}