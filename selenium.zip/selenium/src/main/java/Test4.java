import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Test4 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		driver.get("https://www.saucedemo.com/");
		
		Thread.sleep(1000);
		WebElement Path1=driver.findElement(By.xpath( "//*[@id='user-name']"));
		Thread.sleep(1000);
		WebElement Path2=driver.findElement(By.name("password"));
		Thread.sleep(1000);
		WebElement Path3=driver.findElement(By.id("login-button"));
		
		
		Path1.sendKeys("standard_user");
		System.out.println("Username entered");
		
		Path2.sendKeys("secret_sauce");
		System.out.println("Password Entered");
		
		Path3.click();
		System.out.println("Login success");
		

	}

	
}


//https://www.saucedemo.com/