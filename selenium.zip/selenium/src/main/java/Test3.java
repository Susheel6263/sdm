import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Test3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriverManager.edgedriver().setup();
		WebDriver driver = new EdgeDriver();
		driver.get("https://www.google.com");
		
		//YacQv
		
		WebElement Text1=driver.findElement(By.name("q"));
		
		WebElement btn=driver.findElement(By.className("gNO89b"));
		
		
		Text1.sendKeys("sankeerth");
		System.out.println("clicked");
		
		Text1.sendKeys(Keys.RETURN); // upon returning keys it will enter/search
		System.out.println("donee");
		
//		btn.click();
//		System.out.println("Clickeddd");
		
		
		
	}

}
